package com.example.registration;

public class LatLn {
    public LatLn(double latitude, double longitude) {
    }
}
