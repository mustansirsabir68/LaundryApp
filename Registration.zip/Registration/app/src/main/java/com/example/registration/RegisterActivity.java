package com.example.registration;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class RegisterActivity extends AppCompatActivity {

    TextView inputname, inputUsername, regPhoneno, regPassword, regConfirm,btn1;
    Button btn;
    FirebaseAuth fAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        inputname=findViewById(R.id.inputname);
        inputUsername=findViewById(R.id.inputUsername);

        regPhoneno = findViewById(R.id.inputEmail);
        regPassword = findViewById(R.id.inputPassword);
        regConfirm = findViewById(R.id.inputConformPassword);
        btn= findViewById(R.id.btnRegister);
        btn1=findViewById(R.id.alreadyHaveAccount);

        fAuth=FirebaseAuth.getInstance();

        Button btn=findViewById(R.id.btnRegister);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fullName=inputname.getText().toString();
                String email=inputUsername.getText().toString();
                String Phone=regPhoneno.getText().toString();
                String pass=regPassword.getText().toString();
                String confpass=regConfirm.getText().toString();

                if(fullName.isEmpty()){
                    inputname.setError("Full Name is required");
                    return;
                }
                if(email.isEmpty()){
                    inputUsername.setError("Email-id is required");
                    return;
                }
                if(Phone.isEmpty() || Phone.length()<10){
                    regPhoneno.setError("Please enter a valid Phone No.");
                    return;
                }
                if(pass.isEmpty()){
                    regPassword.setError("Password is mandatory");
                    return;
                }
                if(confpass.isEmpty()){
                    regConfirm.setError("Please enter the password to Confirm");
                    return;
                }

                if(!pass.equals(confpass)){
                    regPassword.setError("Password does not match");
                    return;

                }

                fAuth.createUserWithEmailAndPassword(email,pass).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        startActivity(new Intent(getApplicationContext(),LoginActivity.class));
                        finish();

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(RegisterActivity.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                    }
                });

            }

            });


                TextView btn1 = findViewById(R.id.alreadyHaveAccount);
                btn1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                    }
                });
    }
}
